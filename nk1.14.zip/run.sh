#http://www.mcbbs.net/thread-810442-1-1.html
sudo java -jar nukkit-1.0-SNAPSHOT.jar